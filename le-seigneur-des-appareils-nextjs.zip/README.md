# Le Seigneur des Appareils — Site Next.js

Déploiement rapide sur Vercel: téléversez ce dossier ZIP sur Vercel (Import Project → Upload) et déployez.

Remplace `public/profile.jpg` si tu veux une autre photo.
