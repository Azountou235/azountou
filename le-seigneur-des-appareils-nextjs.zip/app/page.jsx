import React from 'react'
import Image from 'next/image'
import { Mail, Phone, MessageCircle, Globe, Facebook } from 'lucide-react'

export default function Page(){
  return (
    <main className="min-h-screen bg-gradient-to-b from-neutral-900 via-black to-neutral-900 text-slate-100 antialiased p-6">
      <div className="max-w-4xl mx-auto py-12">
        <header className="flex flex-col md:flex-row items-center gap-8">
          <div className="w-40 h-40 rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
            <Image src="/profile.jpg" alt="Mahamat Oumar - Le Seigneur des Appareils" width={400} height={400} />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl md:text-4xl font-extrabold">Le Seigneur des Appareils</h1>
            <p className="mt-3 text-slate-300 max-w-2xl"><strong>Mahamat Oumar Moussa Houma</strong> — Goran du Kanem. Étudiant en sociologie (2ᵉ année) à l'Université HEC Tchad. Passionné d'informatique depuis l'enfance, je construis un pont entre <em>humanité</em> et <em>innovation</em>.</p>
            <div className="mt-6 flex gap-3">
              <a href="mailto:azountouleseigneur@gmail.com" className="inline-flex items-center gap-2 bg-blue-600/20 px-4 py-2 rounded">Contactez-moi</a>
              <a href="#contact" className="inline-flex items-center gap-2 bg-slate-800/40 px-4 py-2 rounded">Mon parcours</a>
            </div>
            <div className="mt-6 flex items-center gap-4">
              <a href="mailto:azountouleseigneur@gmail.com" target="_blank" rel="noreferrer" className="p-2 rounded bg-slate-800/40"><Mail size={18} /></a>
              <a href="https://wa.me/23591234567" target="_blank" rel="noreferrer" className="p-2 rounded bg-slate-800/40"><Phone size={18} /></a>
              <a href="https://t.me/Seigneur_235" target="_blank" rel="noreferrer" className="p-2 rounded bg-slate-800/40"><MessageCircle size={18} /></a>
              <a href="https://www.tiktok.com/@dogordami_1" target="_blank" rel="noreferrer" className="p-2 rounded bg-slate-800/40"><Globe size={18} /></a>
              <a href="https://www.facebook.com/mahamat.oumar.moussa.2025" target="_blank" rel="noreferrer" className="p-2 rounded bg-slate-800/40"><Facebook size={18} /></a>
            </div>
          </div>
        </header>

        <div className="my-12 border-t border-slate-800/60" />

        <section id="parcours" className="grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-semibold">À propos</h2>
            <p className="mt-4 text-slate-300">De mon vrai nom <strong>Mahamat Oumar Moussa Houma</strong>, de l’ethnie <strong>Goran</strong> du Kanem, étudiant en sociologie (2ᵉ année) à l'Université HEC Tchad. Ma passion pour l'informatique remonte à l'enfance. Même si j'étudie la sociologie, mon rêve technologique reste vivant — je cherche à comprendre la société pour mieux concevoir des solutions numériques humaines et responsables.</p>
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Parcours & Études</h2>
            <p className="mt-4 text-slate-300"><strong>Université HEC Tchad</strong> — Étudiant en sociologie (2ᵉ année).</p>
            <div className="mt-6">
              <h4 className="font-medium">Objectifs</h4>
              <ol className="mt-2 list-decimal ml-5 text-slate-300">
                <li>Approfondir mes connaissances en développement web.</li>
                <li>Créer des projets qui répondent aux besoins locaux.</li>
                <li>Construire une communauté tech dans le Kanem.</li>
              </ol>
            </div>
            <div id="contact" className="mt-6">
              <h3 className="font-semibold">Contact</h3>
              <p className="text-slate-300 mt-2">Basé au Tchad — Kanem</p>
            </div>
          </div>
        </section>

        <footer className="mt-12 text-sm text-slate-500">© {new Date().getFullYear()} Le Seigneur des Appareils — Mahamat Oumar Moussa Houma</footer>
      </div>
    </main>
  )
}
